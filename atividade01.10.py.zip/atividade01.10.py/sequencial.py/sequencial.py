import os
os.system("cls")



# nome: digite o nome cliente
nome = float(input("digite o nome:"))
while nome ("digite o nome"):
    print("nome do cliente.")
    nome = float(input("nome cliente:"))
    
# digite: a idade
idade = int(input("Idade: "))
while idade < 0 or idade > 150:
    print("Idade inválida. Deve estar entre 0 e 150.")
    idade = int(input("Idade: "))

# Salário: maior que zero

salario = float(input("Salário: R$ "))
while salario <= 0:
    print("Salário inválido. Deve ser maior que zero.")
    salario = float(input("Salário: R$ "))


# Estado civil: s, c, v ou d

estado_civil = input("Estado civil (s, c, v, d): ").strip().lower()
while estado_civil not in ("s", "c", "v", "d"):
    print("Estado civil inválido. Use s, c, v ou d.")
    estado_civil = input("Estado civil (s, c, v, d): ").strip().lower()


print("\nDados cadastrados:")
print(f"Nome: {nome}")
print(f"Idade: {idade}")
print(f"Salário: R$ {salario:.2f}")
print(f"Estado civil: {estado_civil}")








