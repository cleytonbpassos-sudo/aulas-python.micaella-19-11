import os
os.system("cls")

n = int(input("Digite um número de 1 a 10: "))
while n <  1 or n >  10:
    print("Número valido. Deve estar entre 1 e 10.")
    n = int(input("Digite um número de 1 a 10: "))

print(f"Tabuada de {n}:")
for i in range(1, 11):
    print(f"{n} X {i} = {n * i}")












