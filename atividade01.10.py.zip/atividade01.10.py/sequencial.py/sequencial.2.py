import os
os.system("cls")

n = int(input("Quantos termos da série de Fibonacci você quer ver? "))
while n < 1:
    print("Valor inválido. Deve ser pelo menos 1.")
    n = int(input("Quantos termos da série de Fibonacci você quer ver? "))

a, b = 1, 1
for i in range(n):
    print(a, end=" ")
    a, b = b, a + b
print()













