import os
os.system("cls")

letra = input("Digite uma letra: ").strip().lower()

if len(letra) != 1 or not letra.isalpha():
    print("Entrada inválida. Digite apenas uma letra.")

elif letra in "a e i o u":
    print("Vogal")
else:
    print("Consoante")






