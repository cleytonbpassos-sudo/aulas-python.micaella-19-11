import os
os.system("cls")

n = float(input("Digite um número: "))

if n > 0:
    print("O número é positivo.")
elif n < 0:
    print("O número é negativo.")
else:
    print("O número é zero.")








