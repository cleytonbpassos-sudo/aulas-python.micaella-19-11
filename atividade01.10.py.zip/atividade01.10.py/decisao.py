import os
os.system("cls")

if("morango") <= 5:
    preco_morango = 2.50

else:
 preco_morango = 2.20

if ("maca") <= 5:
 preco_maca = 1.80

else:
 preco_maca = 1.50

total_kg = ("morango + maca")
total = morango * preco_morango + maca * preco_maca

# Desconto de 10% se passar de 8 kg ou de R$ 25,00
if total_kg > 8 or total > 25:
    total = total * 0.90

print(f"Valor a ser pago: R$ {total:.2f}")


















