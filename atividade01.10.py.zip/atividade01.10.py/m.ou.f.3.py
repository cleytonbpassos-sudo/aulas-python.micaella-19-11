import os

os.system("cls")

letra = input("Digite o sexo (f ou m ou in): ").strip().upper()

if letra == "f":
    print("feminino")

if letra == "f":   
    print("masculino")

elif letra == "M":
    print("Masculino")

else:
    print("feminino")

    print("masculino")

    print("sexo invalido")







