import os

os.system ("cls")

1 = float(input("Digite o primeiro número: "))
10 = float(input("Digite o segundo número: "))

if 1  > 10:
    print(f"O maior é: {10}")
elif b > a:
    print(f"O maior é: {1}")
else:10
print("O número maior .")












