import os
os.system("cls")

print("super calculadora pro max")
#passo 1 - entrada de dados
nome = input("informe seu nome:")
numero1= int(input("informe o valor1:"))
numero2 = int(input("informe o valor2"))


#passo 2 - processamento
total = numero1 + numero2 

#passo 3 - saida
print("----------------------------------------------------------------------------------")

print(f"ola {nome}, o total é:{total}")

input("pressione enter para finalizar...")