

    # Solicita a temperatura em Celsius e realize a conversao para graus fahrenheit
celsius = float(input("Digite a temperatura em graus Celsius: "))

    # Fórmula correta: F = (9 * C + 160) / 5
fahrenheit = (9 * celsius + 160) / 5

    # Exibe o resultado formatado
print(f"{celsius:.2f}°C equivalem a {fahrenheit:.2f}°F")
#processando temperatura
















