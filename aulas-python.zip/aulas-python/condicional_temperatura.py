import os
os.system("cls")

temperatura = float ( input ("digite a temperatura em celsius"))

if temperatura >= 30.0:
    print ("está quente!")
elif temperatura>= 20:
    print("esta agradavel!")
elif temperatura>= 10:
    print ("está muito frio!")























