import os
os.system("cls")

print("ola mundo")

